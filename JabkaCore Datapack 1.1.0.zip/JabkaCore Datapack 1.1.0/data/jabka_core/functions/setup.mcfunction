gamerule commandBlockOutput false
gamerule logAdminCommands false




###Готові скорборди для датапаків

#Базові скорборди
scoreboard objectives add health health
scoreboard objectives add food food
scoreboard objectives add level level
scoreboard objectives add armor armor
scoreboard objectives add sneakTime minecraft.custom:sneak_time
scoreboard objectives add deathCount deathCount

#Перевірка ПКМ (два способи)
scoreboard objectives add rightClickDetectionV1 minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add rightClickDetectionV2 minecraft.used:minecraft.warped_fungus_on_a_stick



###JabkaCore Scoreboards

#Підписки JabkaCore
scoreboard objectives add JabkaCore_Subscribes dummy
scoreboard players set *customCraftingTable JabkaCore_Subscribes 0

#Список таймерів JabkaCore
#scoreboard objectives add JabkaCore_Timers dummy

#Скорборди JabkaCore
scoreboard objectives add use_craft dummy