advancement revoke @s only jabka_core:craft_custom_crafting_table
recipe take @s jabka_core:craft_custom_crafting_table
clear @s minecraft:knowledge_book
execute if score *customCraftingTable JabkaCore_Subscribes matches 1 run loot spawn ~ ~ ~ loot jabka_core:custom_crafting_table