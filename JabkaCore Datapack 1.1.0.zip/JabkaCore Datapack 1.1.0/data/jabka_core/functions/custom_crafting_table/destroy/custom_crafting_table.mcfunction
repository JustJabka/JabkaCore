kill @e[type=item,nbt={Item:{id:"minecraft:barrel"}},distance=..1.8,limit=1]
loot spawn ~ ~ ~ loot jabka_core:custom_crafting_table
kill @s