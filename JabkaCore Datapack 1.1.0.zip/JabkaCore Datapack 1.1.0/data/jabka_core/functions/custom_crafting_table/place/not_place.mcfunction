#custom_crafting_table
execute if entity @s[tag=sb.custom_crafting_table] run function jabka_core:custom_crafting_table/destroy/custom_crafting_table