execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if data block ~ ~ ~ Items[{id:"minecraft:knowledge_book",Slot:14b,Count:1b,tag:{clearme:1b,display:{Name:'{"text": "Craft!","italic": false}'}}}] run scoreboard players set @s use_craft 0
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s unless data block ~ ~ ~ Items[{id:"minecraft:knowledge_book",Slot:14b,Count:1b,tag:{clearme:1b,display:{Name:'{"text": "Craft!","italic": false}'}}}] unless data block ~ ~ ~ Items[{Slot:16b}] run scoreboard players set @s use_craft 1

###GUI
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.0 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.4 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.5 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.6 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.7 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.8 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.9 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.13 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.14 with knowledge_book{clearme:1b,display:{Name:'{"text": "Craft!","italic": false}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.15 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
#16 result
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.17 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.18 with armor_stand{clearme:1b,CustomModelData:2,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.22 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.23 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.24 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.25 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~ ~ barrel run item replace block ~ ~ ~ container.26 with armor_stand{clearme:1b,CustomModelData:3,display:{Name:'{"text": ""}'}}