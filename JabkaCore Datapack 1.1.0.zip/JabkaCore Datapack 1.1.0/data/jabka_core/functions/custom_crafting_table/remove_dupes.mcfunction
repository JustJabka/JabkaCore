execute at @s run summon item ~ ~ ~ {Item:{id:"minecraft:hopper_minecart",Count:1b}}
kill @s