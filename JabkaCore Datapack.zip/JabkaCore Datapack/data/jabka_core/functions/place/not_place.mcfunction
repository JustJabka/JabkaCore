#custom_crafting_table
execute if entity @s[tag=sb.custom_crafting_table] run function jabka_core:destroy/custom_crafting_table