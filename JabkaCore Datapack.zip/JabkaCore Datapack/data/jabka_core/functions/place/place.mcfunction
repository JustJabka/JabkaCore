#custom
execute if entity @s[tag=sb.custom_crafting_table] run function jabka_core:place/custom_crafting_table