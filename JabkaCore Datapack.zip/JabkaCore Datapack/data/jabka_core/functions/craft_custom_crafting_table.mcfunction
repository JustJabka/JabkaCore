advancement revoke @s only jabka_core:craft_custom_crafting_table
recipe take @s jabka_core:craft_custom_crafting_table
clear @s minecraft:knowledge_book
loot spawn ~ ~ ~ loot jabka_core:custom_crafting_table