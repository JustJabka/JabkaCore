###place
execute as @e[type=armor_stand,tag=sb.block] at @s if block ~ ~ ~ air run function jabka_core:place/place

execute as @e[type=armor_stand,tag=sb.block] at @s unless block ~ ~ ~ air run function jabka_core:place/not_place
execute as @e[type=armor_stand,tag=sb.block,y=-64] at @s run kill @s

###destroy
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s unless block ~ ~ ~ barrel run function jabka_core:destroy/custom_crafting_table

###anti dupe
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s if block ~ ~-1 ~ hopper run setblock ~ ~-1 ~ air destroy 
execute as @e[type=item_display,tag=dis.custom_crafting_table] at @s run execute positioned ~ ~-1 ~ as @e[type=minecraft:hopper_minecart,distance=..1] run function jabka_core:remove_dupes
clear @a armor_stand{clearme:1b}
kill @e[type=item,nbt={Item:{id:"minecraft:armor_stand",Count:1b,tag:{clearme:1b}}}]

###gui
function jabka_core:gui